import React from "react";
import "./park.css";

const ParkComponent = () => {
  return (
    <div>
      <div className="park-image">
        <img
          src="Open Park+ App (1).png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "6rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="open-park-text">
        <h4 className="open-park">Open Park+ app</h4>
      </div>
      <div className="paragraph-open-park">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "41rem",
            marginTop: "2rem",
          }}
        >
          Open Park+ app Open Park+ app & Choose Challan as a service
        </p>
      </div>
      <div className="enter-vehicle-number-image">
        <img
          src="Enter Vehicle Number (1).png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "8rem",
          }}
        ></img>
      </div>
      <div className="vehicle-number-text">
        <h4 className="vehicle-number">Enter Vehicle Number</h4>
      </div>
      <div className="paragraph-vehicle-number">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "36rem",
            marginTop: "2rem",
          }}
        >
          Mention your vehicle registration number, and click on the Challan
          details
        </p>
      </div>
      <div className="challan-status-image">
        <img
          src="Check the e-challan status (1).png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="check-e-challan-status">
        <h4 className="e-challan-status">Check the E-Challan Status</h4>
      </div>
      <div className="paragraph-challan-status">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "44rem",
            marginTop: "2rem",
          }}
        >
          Now, click on the update button to check the e-challan status
        </p>
      </div>
      <div className="pending-challan-image">
        <img
          src="Check & Pay pending challans (1).png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-pending-challan">
        <h4 className="pending-challan">Check & Pay Pending Challans</h4>
      </div>
      <div className="paragraph-pending-challan">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "45rem",
            marginTop: "2rem",
          }}
        >
          Once done, check your challan, and pay the pending fees
        </p>
      </div>
      <div className="recieve-confirmation-image">
        <img
          src="Receive a confirmation with transaction ID (1).png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-recieve-confirmation">
        <h4 className="recieve-confirmation">
          Receive a confirmation with transaction ID
        </h4>
      </div>
      <div className="paragraph-recieve-confirmation">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "4rem",
            marginTop: "2rem",
          }}
        >
          After a successful transaction, you will receive5 a confirmation on
          your respective mobile number along with the transaction ID
        </p>
      </div>
    </div>
  );
};

export default ParkComponent;
