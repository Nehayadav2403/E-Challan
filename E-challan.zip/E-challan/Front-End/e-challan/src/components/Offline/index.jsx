import React from "react";
import "./offline.css";

const Offline = () => {
  return (
    <div>
      <div className="visit-traffic-police-image">
        <img
          src="Visit Police Station.png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-visit-traffic-police">
        <h4 className="visit-traffic-police">Visit traffic police station</h4>
      </div>
      <div className="paragraph-visit-traffic-police">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "54rem",
            marginTop: "2rem",
          }}
        >
          Visit any traffic police station in your locality
        </p>
      </div>
      <div className="valid-documents-image">
        <img
          src="carry valid documents.png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-valid-documents">
        <h4 className="valid-documents">Carry valid documents</h4>
      </div>
      <div className="paragraph-valid-documents">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "15rem",
            marginTop: "2rem",
          }}
        >
          Carry your Identity Proof, Driving Licence and the letter of traffic
          violation (either printed or screenshot/ PDF)
        </p>
      </div>
      <div className="pay-fine-image">
        <img
          src="select e challlan.png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-pay-fine">
        <h4 className="pay-fine">Pay fine</h4>
      </div>
      <div className="paragraph-pay-fine">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "71rem",
            marginTop: "2rem",
          }}
        >
          Submit you fine
        </p>
      </div>
      <div className="get-a-receipt-image">
        <img
          src="Get a Receipt.png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-get-a-receipt">
        <h4 className="get-a-receipt">Get a receipt</h4>
      </div>
      <div className="paragraph-get-a-receipt">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "62rem",
            marginTop: "2rem",
          }}
        >
          Pay via Cash and get a receipt
        </p>
      </div>
    </div>
  );
};

export default Offline;
