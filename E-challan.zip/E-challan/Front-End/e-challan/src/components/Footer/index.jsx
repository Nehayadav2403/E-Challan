import React from "react";

const Footer = () => {
  return (
    <div className="footer">
      <div className="h3-heading-park-text">
        <h3
          className="park-text"
          style={{
            display: "flex",
            flexDirection: "column",
            margin: "auto",
            marginTop: "1rem",
            background: "darkorchid",
            height: "10rem",
            paddingRight: "76rem",
            color: "white",
            paddingTop: "4rem",
          }}
        >
          © 2020 Park+. All rights reserved
        </h3>
      </div>
      <div className="h4-heading-terms-condition">
        <h4
          className="terms-condition"
          style={{
            fontSize: "21px",
            lineHeight: "24px",
            marginTop: "-5rem",
            paddingLeft: "95rem",
            color: "white",
          }}
        >
          Terms & Conditions | Privacy Policy
        </h4>
      </div>
    </div>
  );
};

export default Footer;
