import React from "react";
function Navbar() {
  return (
    <div className="container" style={{ maxWidth: "100%" }}>
      <nav
        className="navbar navbar-expand-lg bg-body-tertiary"
        style={{ height: "5rem" }}
      >
        <div className="container-fluid">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <div>
              <img
                src="WhatsApp_Image_2024-09-20_at_15.31.32_d5c1b748-removebg-preview.png"
                alt="No logo found"
                style={{ width: "14rem" }}
              />
            </div>
            <div>
              <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    aria-current="page"
                    href="#"
                    style={{
                      position: "relative",
                      left: "50rem",
                      fontWeight: 600,
                      fontSize: "28px",
                      lineHeight: "14px",
                      color: "#000",
                      width: "100%",
                      height: "100%",
                      display: "inline-block",
                      fontFamily: "RobotoNormal, sans-serif",
                    }}
                  >
                    Home
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    aria-current="page"
                    href="#"
                    style={{
                      position: "relative",
                      left: "55rem",
                      fontWeight: 600,
                      fontSize: "28px",
                      lineHeight: "14px",
                      color: "#000",
                      width: "100%",
                      height: "100%",
                      display: "inline-block",
                      fontFamily: "RobotoNormal, sans-serif",
                    }}
                  >
                    About
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    aria-current="page"
                    href="#"
                    style={{
                      position: "relative",
                      left: "60rem",
                      fontWeight: 600,
                      fontSize: "28px",
                      lineHeight: "14px",
                      color: "#000",
                      width: "100%",
                      height: "100%",
                      display: "inline-block",
                      fontFamily: "RobotoNormal, sans-serif",
                    }}
                  >
                    Contact Us
                  </a>
                </li>
                <li className="nav-item">
                  <a
                    className="nav-link active"
                    aria-current="page"
                    href="#"
                    style={{
                      position: "relative",
                      left: "65rem",
                      fontWeight: 600,
                      fontSize: "28px",
                      lineHeight: "14px",
                      color: "#000",
                      width: "100%",
                      height: "100%",
                      display: "inline-block",
                      fontFamily: "RobotoNormal, sans-serif",
                    }}
                  >
                    Careers
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}

export default Navbar;
