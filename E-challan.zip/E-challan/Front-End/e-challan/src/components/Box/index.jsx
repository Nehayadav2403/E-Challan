import React from "react";
import "./next.css";

const Boxes = () => {
  return (
    <div className="container">
      <div className="check-e-challan">
        <div className="h2-heading-check-e-challan">
          <h2 className="check-challan">How to Check Your E-Challan</h2>
        </div>
        <div className="row">
          <div className="first-col-6">
            <div className="h3-heading-text">
              <h3 className="step-for-check-challan">
                Steps to Check Challan Using the Park+ app
              </h3>
            </div>
            <div className="paragraph-visit-app">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "25rem",
                  marginTop: "2rem",
                }}
              >
                1. Visit the Park+ website or open the app.
              </p>
            </div>
            <div className="click-challan">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "33rem",
                  marginTop: "1rem",
                }}
              >
                2. Click on the "Challan" tab.
              </p>
            </div>
            <div className="enter-vehicle-number">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "9rem",
                  marginTop: "1rem",
                }}
              >
                3. Enter your vehicle registration number and click on Challan
                Details.
              </p>
            </div>
            <div className="find-update-button">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "1rem",
                  marginTop: "1rem",
                }}
              >
                4. You will find an update button,which once you click,will ask
                you to "Update now".
              </p>
            </div>
            <div className="get-e-challan-status">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "10rem",
                  marginTop: "1rem",
                }}
              >
                5. Once you click on "Update now",you will get the e-challan
                status.
              </p>
            </div>
            <div className="first-box-image">
              <img src="i_Phone_12_Pro.webp" alt=""></img>
            </div>
          </div>
          <div className="second-col-6">
            <div className="h3-heading-parivahan-website">
              <h3 className="parivahan-website">
                Steps to Check Challan Using Parivahan website
              </h3>
            </div>
            <div className="visit-parivahan-website">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "2rem",
                  marginTop: "2rem",
                }}
              >
                1. Visit the Parivahan Website: Go to the eChallan System Link
                and a login page will appear.
              </p>
            </div>
            <div className="click-get-challan-details">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "4rem",
                  marginTop: "1rem",
                }}
              >
                2. Click on Get Challan Details: You have the option to choose
                between Challan Number,Vehicle Number and DL Number.
              </p>
            </div>
            <div className="enter-details-captcha">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "8rem",
                  marginTop: "1rem",
                }}
              >
                3. Enter Details and Captcha: Details of the Challan(if any)
                will be shown.
              </p>
            </div>
            <div className="select-e-challan">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "7rem",
                  marginTop: "1rem",
                  width: "51rem",
                }}
              >
                4. Select the e-Challan: Get Details of the offence and penalty
                to be paid.
              </p>
            </div>
            <div className="proceed-the-payment">
              <p
                style={{
                  fontSize: "21px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingRight: "4rem",
                  marginTop: "1rem",
                }}
              >
                Proceed with the Payment: Upon Successful completion,you will
                recieve a confirmation along with the transaction ID.
              </p>
            </div>
            <div className="studio-display-image">
              <img src="Studio_Display.webp" alt=""></img>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Boxes;
