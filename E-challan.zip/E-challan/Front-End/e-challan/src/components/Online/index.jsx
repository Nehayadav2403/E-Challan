import React from "react";
import "./online.css";

const Online = () => {
  return (
    <div>
      <div className="visit-parivahan-image">
        <img
          src="visit parivahan website.png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-visit-parivahan">
        <h4 className="visit-parivahan">Visit the Parivahan Website</h4>
      </div>
      <div className="paragraph-visit-parivahan">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "43rem",
            marginTop: "2rem",
          }}
        >
          Go to the eChallan System Link, and a login page will appear
        </p>
      </div>
      <div className="get-challan-details-image">
        <img
          src="click on get challan details.png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-get-challan-details">
        <h4 className="get-challan-details">Click on Get Challan Details</h4>
      </div>
      <div className="paragraph-get-challan-details">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "25rem",
            marginTop: "2rem",
          }}
        >
          Choose between Challan Number, Vehicle Number or DL Number to mention
          the car details
        </p>
      </div>
      <div className="details-captcha-image">
        <img
          src="Enter Details and captcha.png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-details-captcha">
        <h4 className="details-captcha">Enter Details and Captcha</h4>
      </div>
      <div className="paragraph-details-captcha">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "54rem",
            marginTop: "2rem",
          }}
        >
          Details of the Challan (if any) will be shown
        </p>
      </div>
      <div className="select-e-challan-image">
        <img
          src="Proceed with the payment option.png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-select-e-challan">
        <h4 className="select-e-challan">Select the e-Challan</h4>
      </div>
      <div className="paragraph-select-e-challan">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "51rem",
            marginTop: "2rem",
          }}
        >
          Get details of the offence and penalty to be paid
        </p>
      </div>
      <div className="proceed-payment-image">
        <img
          src="select e challlan.png"
          alt=""
          style={{
            position: "relative",
            right: "52rem",
            top: "5rem",
            width: "5rem",
          }}
        ></img>
      </div>
      <div className="h4-heading-proceed-payment">
        <h4 className="proceed-payment">Proceed with the Payment</h4>
      </div>
      <div className="paragraph-proceed-payment">
        <p
          style={{
            fontSize: "22px",
            lineHeight: "20px",
            fontFamily: "RobotoNormal, sans-serif",
            marginRight: "27rem",
            marginTop: "2rem",
          }}
        >
          Upon successful completion, you will receive a confirmation along with
          the transaction ID
        </p>
      </div>
    </div>
  );
};

export default Online;
